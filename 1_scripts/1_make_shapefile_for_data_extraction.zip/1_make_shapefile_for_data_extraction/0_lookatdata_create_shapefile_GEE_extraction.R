library(tidyverse)
library(sf)
library(ggplot2)
library(grid)
library(gridExtra)
library(terra)
yera<-read.csv("0_data/0_raw/point counts/YERA_2024_COLEXT_DATA_NAMECROSSWALK.csv", header=TRUE)
str(yera)#247 rows
nlevels(as.factor(yera$location))#247
nlevels(as.factor(yera$locationC))#237

#Use the NOT rounded lat/ long when you can. Only when there is movement of the points slightly over time will the round be more appropriate
yera2<-yera%>%
  group_by(locationC)%>%
  mutate(nSitesUsed=nlevels(as.factor(location)))%>%
  group_by(locationC,nSitesUsed)%>%
  summarise(lat=ifelse(nSitesUsed>1, R_latitude, latitude),
            lon=ifelse(nSitesUsed>1, R_longitude, longitude))%>%
  unique()#237 sites now


plot(yera2$lon, yera2$lat) #no obvious points appear to be off.
#no missing coordinates
a1<-st_as_sf(yera2,
            coords = c("lon", "lat"),
            crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")%>%
  st_write("0_data/0_raw/point counts/allYERAsites_May2025.shp", append=FALSE)
st_bbox(a1)


pts.ssyr<-rbind(yera2,yera2,yera2,yera2,yera2,yera2,yera2,yera2,yera2,yera2,yera2) #11 = 2023 - 2013 + 1
pts.ssyr<-pts.ssyr%>%
  arrange(locationC)#sort by site
pts.ssyr$year<-rep(seq(2013,2023,1),nrow(yera2))

E<-st_as_sf(pts.ssyr,
            coords = c("lon", "lat"),
            crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")%>%
  st_write("0_data/0_raw/point counts/allYERAsites_allyears_April2024.shp", append=FALSE)

#At this point, I can use the shapefile in Google Earth Engine, R or ArcGIS to extract spatial
#data to sites, whether there is survey data for each site in a particular year or not.
E<-st_read("0_data/0_raw/point counts/allYERAsites_allyears_April2024.shp")
st_bbox(E)
#      xmin       ymin       xmax       ymax 
#-113.90530   54.43446 -110.05960   57.69631

#As of June 2025, there is also additional YERA data that I should look at from Suncor
yera_Suncor<-read.csv("0_data/0_raw/point counts/downloaded 2025/SUNCOR_Yellow_Rail_Visual_Scanning_main_report.csv", header=TRUE)
str(yera_Suncor)
SuncorLocationnames<-levels(as.factor(yera_Suncor$location))#92, some of which we already have
yera_Suncor_already<-yera_Suncor%>%
  filter(location %in% levels(as.factor(yera$location)))
levels(as.factor(yera_Suncor_already$location))#45
yera_Suncor_already%>%
  select(location, recording_date_time)

yera_Suncor_new<-yera_Suncor%>%
  filter(!location %in% levels(as.factor(yera$location)))
levels(as.factor(yera_Suncor_new$location))#47

library(lubridate)
yera_Suncor<-yera_Suncor%>%
#From yera_Suncor, get:
  mutate(detected=case_when(species_code=="YERA" ~ 1,
                            !species_code=="YERA" ~ 0))%>%
  #Yellow Rails detected or not
  mutate(year=substr(recording_date_time,1,4))%>%
  #extract year
  mutate(date=substr(recording_date_time,1,10))%>%
  mutate(Date=as.Date(date, "%Y-%m-%d"))%>%
  mutate(julian=yday(Date))%>%
  #recording date and Julian date
  mutate(time=substr(recording_date_time,11,13))%>%
  mutate(hour=as.integer(time))%>%
  #recording time of day
  filter(hour<5)%>%arrange(location,year,julian)%>%
  #get visit number per year for each location, starting with 1
  group_by(location,year)%>%
  mutate(visit = 1:n()) %>%
  ungroup()%>%
  filter(visit<6)%>%
  mutate(year_visit=paste0("yera",year,"_",visit))
  #no more than 5 visits per year: random sample from up to 5 visits?

yera_Suncor_wide<-yera_Suncor%>%
  group_by(location)%>%
  mutate(counta=n())%>%
  select(counta, location, latitude, longitude, year_visit, detected)%>%
  mutate(R_latitude=round(latitude,3),
         R_longitude=round(longitude,3))%>%
  pivot_wider(names_from=year_visit,
              values_from=detected)
#write.csv(yera_Suncor_wide, file="0_data/0_raw/point counts/YERA_Suncor2025_COLEXT_DATA_DETECTIONHISTORY.csv")

#get locationC from cross-walk
crossWalk<-read.csv("0_data/0_raw/point counts/YERA_2024_COLEXT_DATA_NAMECROSSWALK.csv", header=TRUE)
max(crossWalk$locationC)
yera_Suncor_wide2<-merge(yera_Suncor_wide, crossWalk, by=c("location"#,
                                                           #"latitude",
                                                           #"longitude",
                                                           #"R_latitude",
                                                           #"R_longitude"
                                                           ), all.x=TRUE)

yera_Suncor_wide2<-yera_Suncor_wide2%>%
  mutate(latitude=latitude.x,
         longitude=longitude.x,
         R_latitude=R_latitude.x,
         R_longitude=R_longitude.x)
yera_Suncor_wide2$latitude.x<-NULL
yera_Suncor_wide2$latitude.y<-NULL
yera_Suncor_wide2$R_latitude.x<-NULL
yera_Suncor_wide2$R_latitude.y<-NULL
yera_Suncor_wide2$longitude.x<-NULL
yera_Suncor_wide2$longitude.y<-NULL
yera_Suncor_wide2$R_longitude.x<-NULL
yera_Suncor_wide2$R_longitude.y<-NULL
write.csv(yera_Suncor_wide2, file="0_data/0_raw/point counts/YERA_Suncor2025_COLEXT_DATA_DETECTIONHISTORY.csv")

#get previously used detection history file for 2013 - 2023
yeraDetections2013_2023<-read.csv("0_data/0_raw/point counts/YERA_2024_COLEXT_DATA_DETECTIONHISTORY.csv", header=TRUE)
max(yeraDetections2013_2023$locationC)#330

yeraDetections2013_2023updated<-bind_rows(yeraDetections2013_2023,
                                          yera_Suncor_wide2)
yeraDetections2013_2023updated<-yeraDetections2013_2023updated%>%
  arrange(locationC,location)
write.csv(yeraDetections2013_2023updated, file="0_data/0_raw/point counts/YERA_2025_COLEXT_DATA_DETECTIONHISTORY.csv")
#at this point assign "locationC" numbers to those Suncor sites that don't already have them,
#from 331 to 377
#Note that site 352 is lacking lat-long information and will be dropped when making the shapefile.

#Create updated shapefile for data extraction
#Older data 2013-2023 from outside of LGL / Suncor
yera<-read.csv("0_data/0_raw/point counts/YERA_2024_COLEXT_DATA_NAMECROSSWALK.csv", header=TRUE)
str(yera)#247 rows
nlevels(as.factor(yera$location))#247
nlevels(as.factor(yera$locationC))#237

#Use the NOT rounded lat/ long when you can. Only when there is movement of the points slightly over time will the round be more appropriate
yera2<-yera%>%
  group_by(locationC)%>%
  mutate(nSitesUsed=nlevels(as.factor(location)))%>%
  group_by(locationC,nSitesUsed)%>%
  summarise(lat=ifelse(nSitesUsed>1, R_latitude, latitude),
            lon=ifelse(nSitesUsed>1, R_longitude, longitude))%>%
  unique()#237 sites now

plot(yera2$lon, yera2$lat) #no obvious points appear to be off.
#no missing coordinates
a1<-st_as_sf(yera2,
             coords = c("lon", "lat"),
             crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")%>%
  st_write("0_data/0_raw/point counts/allYERAsites_May2025.shp", append=FALSE)
st_bbox(a1)

yera3<-yera_Suncor_wide2%>%
  filter(!location %in% levels(as.factor(yera$location)))
nrow(yera3)#47
yera3<-yera3%>%
  mutate(locationC=seq(331,377,by=1))%>%
  select(location,locationC,R_latitude,R_longitude)%>%
  filter(!is.na(R_latitude))#locationC IDs look all right

yera3[1,]$location
#Before we merge yera3 with yera2, we want to get the most precise lat/long locations again
latLongList<-list()
for (i in 1:nrow(yera3)){
  yera_i<-yera3[i,]
  latitude<-yera_Suncor_wide2%>%
    filter(location==yera_i$location)%>%
    select(latitude)
  longitude<-yera_Suncor_wide2%>%
    filter(location==yera_i$location)%>%
    select(longitude)
  latLongList[[i]]<-cbind(yera_i,latitude,longitude)
}
yera3b<-do.call(rbind,latLongList)
#Use the NOT rounded lat/ long when you can. Only when there is movement of the points slightly over time will the round be more appropriate
yera3c<-yera3b%>%
  group_by(locationC)%>%
  mutate(nSitesUsed=nlevels(as.factor(location)))%>%
  group_by(locationC,nSitesUsed)%>%
  summarise(lat=ifelse(nSitesUsed>1, R_latitude, latitude),
            lon=ifelse(nSitesUsed>1, R_longitude, longitude))%>%
  unique()

a2<-st_as_sf(yera3c,
             coords = c("lon", "lat"),
             crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")%>%
  st_write("0_data/0_raw/point counts/allSuncorYERAsites_June2025.shp", append=FALSE)

finalYERAsites<-bind_rows(yera2,yera3c)

#Assign points to clusters based on their spatial coordinates
# Example: 8 clusters (looks like there are at least 8 clusters in Google Earth)
k <- 10 
#finalYERAsitesShapefile$lon<-st_coordinates(finalYERAsitesShapefile)[,1]
#finalYERAsitesShapefile$lat<-st_coordinates(finalYERAsitesShapefile)[,2]
cluster_result <- kmeans(unlist(finalYERAsites[, c("lon", "lat")]), centers = k, nstart = 25)
finalYERAsites$clusterID1<-cluster_result$cluster[1:283]#longitude assignments
finalYERAsites$clusterID2<-cluster_result$cluster[284:566]#latitude assignments
finalYERAsites$clusterID<-paste0(finalYERAsites$clusterID1,"_",
                               finalYERAsites$clusterID2)
finalYERAsitesShapefile<-st_as_sf(finalYERAsites,
             coords = c("lon", "lat"),
             crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")%>%
  st_write("0_data/0_raw/point counts/allYERAsites_June2025.shp", append=FALSE)

plot(finalYERAsitesShapefile["clusterID"])
#take a look at sites in Google Earth

