library(unmarked)#for running dynamic occu. models based on maximum likelihood
#run models in unmarked package in R. Pick a best model and rerun in JAGS
library(dplyr)#for manipulating data frames
library(tidyr)#for manipulating data frames
library(sf)#for manipulating shapefile spatial data
library(terra)#for manipulating raster spatial data
library(MuMIn)#for likelihood-based model selection
library(AICcmodavg)#for Mackenzie-Bailey goodness-of-fit
library(ggplot2)#for plotting
library(grid)#for multipanel plots
library(gridExtra)#for multipanel plots
library(viridisLite)
theme_set(theme_minimal())

my.theme <- theme_classic() +
  theme(text=element_text(size=16, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))


#Hedley plus RS hybrid models
#get observations
finalYERAsitesShapefile<-st_read("0_data/0_raw/point counts/allYERAsites_June2025.shp")
finalYERAsitesShapefile$lat<-st_coordinates(finalYERAsitesShapefile)[,2]
finalYERAsitesShapefile$long<-st_coordinates(finalYERAsitesShapefile)[,1]
str(finalYERAsitesShapefile)
#need clusterIDs corrected so that a couple too-large
#clusters are split up among wetlands
finalYERAsitesShapefile<-finalYERAsitesShapefile%>%
  mutate(clusterIDfinal=clusterID)%>%
  mutate(clusterIDfinal=case_when(locationC %in% c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16) ~ "2_8b",
                                  locationC %in% c(64,65,58) ~ "7_8b",
                                  locationC %in% c(60,61,62,63) ~ "7_8c",
                                  locationC %in% c(53,54,55,56) ~ "7_8d",
                                  !locationC %in% c(1:16,53:56,58,60:65) ~ clusterID))
levels(as.factor(finalYERAsitesShapefile$clusterIDfinal))


obs<-read.csv("0_data/0_raw/point counts/YERA_2025_COLEXT_DATA_DETECTIONHISTORYcombined.csv", header=TRUE)
#manually went through to combine detection histories stored on multiple rows
#for same sites, condensed detection histories to single row per site.

#This analysis will use 2016 - 2021 and sites
#from the whole YERA study area. 2016 is start year
#because that is earliest year we have Sentinel data for.
#2021 is the end year because southern sites were
#not systematically surveyed beyond 2021
obsFilt<-obs%>%
  select("yera2016_1","yera2016_2","yera2016_3","yera2016_4", 
         "yera2016_5","yera2017_1","yera2017_2","yera2017_3","yera2017_4", 
         "yera2017_5","yera2018_1","yera2018_2","yera2018_3","yera2018_4", 
         "yera2018_5","yera2019_1","yera2019_2","yera2019_3","yera2019_4", 
         "yera2019_5","yera2021_1","yera2021_2","yera2021_3","yera2021_4", 
         "yera2021_5")%>%
  mutate(numVisits=rowSums(!is.na(.)))%>%
  mutate(locationC=obs$locationC)

#,"yera2022_1","yera2022_2","yera2022_3","yera2022_4", 
#"yera2022_5","yera2023_1","yera2023_2","yera2023_3","yera2023_4", 
#"yera2023_5"

m1<-merge(finalYERAsitesShapefile, obsFilt, by=c("locationC"))
str(m1)

#both mining and non-mining regions, but limit to sites
#with at least 3 years of visits
m2<-m1%>%
  filter(numVisits>10)%>%
  arrange(locationC)%>%
  unique()#at least 3 years of visits
str(m2)
table(m2$clusterID)#125 sites, 8 clusters
#Note: not all sites might be covered by Hedley layer
#2_10  2_8  3_1  3_6  3_8  4_5  7_5  7_8 
#   5   15   12    7    7   36   29   14

#get covariates affecting initial occu.
initFilt<-m2%>%
  #select(locationC, clusterID)%>%
  arrange(locationC)
#125 sites with at least 3 years of data from 2016 - 2021

#Hedley et al. layer
Hedley2019<-rast("0_data/1_processed/6_HedleyEtAl2019/YERA_COLL_SUM_FINAL11.tif")
plot(Hedley2019$YERA_COLL_SUM_FINAL11)
raster_bbox<-st_bbox(Hedley2019)
bbox_polygon <- st_as_sfc(raster_bbox)
bbox_sf<-st_as_sf(bbox_polygon)

#Reproject points to Hedley layer's CRS
initFilt.rp<-initFilt%>%
  st_set_crs("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")%>%
  st_transform(crs=st_crs(Hedley2019))
#Extract values from Hedley layer to points
habSuitability<-terra::extract(Hedley2019, initFilt.rp)
hist(habSuitability$YERA_COLL_SUM_FINAL11)
table(habSuitability$YERA_COLL_SUM_FINAL11)
#116 sites with 3+ years of data
#overlapping Hedley layer

#Value:   2  3  4  5  6  7  8 
#nsite:   1  5  3 18 29 30 30

initFilt.rp$HabSuitOrig<-habSuitability$YERA_COLL_SUM_FINAL11
initFilt.rp$HabSuit4Class<-ifelse(initFilt.rp$HabSuitOrig<6, "5orless", initFilt.rp$HabSuitOrig)
#turns it to charactor
initFilt.rp$HabSuit4Class<-as.factor(initFilt.rp$HabSuit4Class)

obsFiltFinal<-initFilt.rp%>%
  filter(!is.na(HabSuitOrig))%>%
  select(yera2016_1,yera2016_2,yera2016_3,yera2016_4,yera2016_5,
         yera2017_1,yera2017_2,yera2017_3,yera2017_4,yera2017_5,
         yera2018_1,yera2018_2,yera2018_3,yera2018_4,yera2018_5,
         yera2019_1,yera2019_2,yera2019_3,yera2019_4,yera2019_5,
         yera2021_1,yera2021_2,yera2021_3,yera2021_4,yera2021_5)
obsFiltFinal$geometry<-NULL
obsFiltFinal<-as.matrix(obsFiltFinal)

siteCovFinal<-initFilt.rp%>%
  filter(!is.na(HabSuitOrig))%>%
  select(locationC, lat, long, clusterID, clusterIDfinal, HabSuit4Class)%>%
  mutate(HabSuit4ClassNumeric=as.numeric(HabSuit4Class))
siteCovFinal$geometry<-NULL

HabSuit4ClassNumeric<-siteCovFinal$HabSuit4ClassNumeric
yearlyHabSuit4Class<-as.matrix(cbind(HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric,
                                     HabSuit4ClassNumeric))

Latitude<-siteCovFinal$lat
yearlyLatitude<-as.matrix(cbind(Latitude,Latitude,Latitude,Latitude,Latitude))

Longitude<-siteCovFinal$long
yearlyLongitude<-as.matrix(cbind(Longitude,Longitude,Longitude,Longitude,Longitude))

#get top yearly raw and static RS variables at locations in siteCovFinal
#Sentinel-1
#DPOL = cross polarization ration
sentinel1_DPOL_2016<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2016DPOL_summer.csv", header=TRUE)
sentinel1_DPOL_2016Filt<-sentinel1_DPOL_2016%>%
  mutate(year=2016,
         DPOL_150summer=mean_mean_150)%>%
  select(locationC,year,DPOL_150summer)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)#71

sentinel1_DPOL_2017<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2017DPOL_summer.csv", header=TRUE)
sentinel1_DPOL_2017Filt<-sentinel1_DPOL_2017%>%
  mutate(year=2017,
         DPOL_150summer=mean_mean_150)%>%
  select(locationC,year,DPOL_150summer)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)

sentinel1_DPOL_2018<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2018DPOL_summer.csv", header=TRUE)
sentinel1_DPOL_2018Filt<-sentinel1_DPOL_2018%>%
  mutate(year=2018,
         DPOL_150summer=mean_mean_150)%>%
  select(locationC,year,DPOL_150summer)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)

sentinel1_DPOL_2019<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2019DPOL_summer.csv", header=TRUE)
sentinel1_DPOL_2019Filt<-sentinel1_DPOL_2019%>%
  mutate(year=2019,
         DPOL_150summer=mean_mean_150)%>%
  select(locationC,year,DPOL_150summer)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)

#N/A: data available but no YERA point counts in this year
#sentinel1_DPOL_2020<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2020DPOL_summer.csv", header=TRUE)
#sentinel1_DPOL_2020Filt<-sentinel1_DPOL_2020%>%
#  mutate(year=2020,
#         DPOL_150summer=mean_mean_150)%>%
#  select(locationC,year,DPOL_150summer)%>%
#  filter(locationC %in% levels(as.factor(m4$locationC)))%>%
#  arrange(locationC)

sentinel1_DPOL_2021<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2021DPOL_summer.csv", header=TRUE)
sentinel1_DPOL_2021Filt<-sentinel1_DPOL_2021%>%
  mutate(year=2021,
         DPOL_150summer=mean_mean_150)%>%
  select(locationC,year,DPOL_150summer)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)

sentinel1_all<-bind_rows(sentinel1_DPOL_2016Filt,
                         sentinel1_DPOL_2017Filt,
                         sentinel1_DPOL_2018Filt,
                         sentinel1_DPOL_2019Filt,
                         #sentinel1_DPOL_2020Filt,
                         sentinel1_DPOL_2021Filt)

#get variables in site major, year minor order
yearlyDPOLsummer<-sentinel1_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,DPOL_150summer)%>%
  pivot_wider(names_from=year,values_from=DPOL_150summer)#208 rows: 7 years at each of 208 sites

#These are year-specific values. Get an averaged value across years for each site
#since static DPOLsummer did slightly better than yearly DPOLsummer AIC-wise
staticDPOLsummer<-sentinel1_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,DPOL_150summer)%>%
  group_by(locationC)%>%
  summarise(sDPOLsummer=mean(DPOL_150summer))

siteCovFinal$sDPOLsummer<-staticDPOLsummer[,2]
#siteCovFinal$DPOLsummer<-yearlyDPOLsummer$`2016`
sDPOLsummer<-staticDPOLsummer[,2]

#VH = summer VH minus fall VH
sentinel1_deltaVH_2016<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2016VHdiff.csv", header=TRUE)
sentinel1_deltaVH_2016Filt<-sentinel1_deltaVH_2016%>%
  mutate(year=2016,
         deltaVH_150=mean_mean_150)%>%
  select(locationC,year,deltaVH_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)%>%
  mutate(deltaVH_150=ifelse(is.na(deltaVH_150), mean(deltaVH_150, na.rm=T), deltaVH_150))

sentinel1_deltaVH_2017<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2017VHdiff.csv", header=TRUE)
sentinel1_deltaVH_2017Filt<-sentinel1_deltaVH_2017%>%
  mutate(year=2017,
         deltaVH_150=mean_mean_150)%>%
  select(locationC,year,deltaVH_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)%>%
  mutate(deltaVH_150=ifelse(is.na(deltaVH_150), mean(deltaVH_150, na.rm=T), deltaVH_150))

sentinel1_deltaVH_2018<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2018VHdiff.csv", header=TRUE)
sentinel1_deltaVH_2018Filt<-sentinel1_deltaVH_2018%>%
  mutate(year=2018,
         deltaVH_150=mean_mean_150)%>%
  select(locationC,year,deltaVH_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)%>%
  mutate(deltaVH_150=ifelse(is.na(deltaVH_150), mean(deltaVH_150, na.rm=T), deltaVH_150))

sentinel1_deltaVH_2019<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2019VHdiff.csv", header=TRUE)
sentinel1_deltaVH_2019Filt<-sentinel1_deltaVH_2019%>%
  mutate(year=2019,
         deltaVH_150=mean_mean_150)%>%
  select(locationC,year,deltaVH_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)%>%
  mutate(deltaVH_150=ifelse(is.na(deltaVH_150), mean(deltaVH_150, na.rm=T), deltaVH_150))

sentinel1_deltaVH_2021<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 1 data/Sentinel1_Indices_YERA_2021VHdiff.csv", header=TRUE)
sentinel1_deltaVH_2021Filt<-sentinel1_deltaVH_2021%>%
  mutate(year=2021,
         deltaVH_150=mean_mean_150)%>%
  select(locationC,year,deltaVH_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))%>%
  arrange(locationC)%>%
  mutate(deltaVH_150=ifelse(is.na(deltaVH_150), mean(deltaVH_150, na.rm=T), deltaVH_150))

sentinel1_deltaVH<-bind_rows(sentinel1_deltaVH_2016Filt,
                             sentinel1_deltaVH_2017Filt,
                             sentinel1_deltaVH_2018Filt,
                             sentinel1_deltaVH_2019Filt,
                             #sentinel1_deltaVH_2020Filt,
                             sentinel1_deltaVH_2021Filt)

#get variables in site major, year minor order
yearlyDeltaVH<-sentinel1_deltaVH%>%
  arrange(locationC,year)%>%
  select(locationC,year,deltaVH_150)%>%
  pivot_wider(names_from=year,values_from=deltaVH_150)

siteCovFinal$DeltaVH<-yearlyDeltaVH$`2016`
#We won't bother with static DeltaVH since it didn't perform as well AIC-wise as yearly 

#Sentinel-2
sentinel2_2016<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 2 data/Sentinel2_Indices_YERASites_2016.csv", header=TRUE)
sentinel2_2016Filt<-sentinel2_2016%>%
  filter(month==6)%>%
  select(locationC,year,ARI_mean_150,BSI_mean_150,   
         EVI_mean_150,LAI_mean_150,MSAVI2_mean_150,
         NBR_mean_150,NDMI_mean_150,NDRE_mean_150,NDVI_mean_150,  
         NDWI_mean_150,REIP_mean_150,SAVI_mean_150,  
         SI_mean_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))

sentinel2_2017<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 2 data/Sentinel2_Indices_YERASites_2017.csv", header=TRUE)
sentinel2_2017Filt<-sentinel2_2017%>%
  filter(month==6)%>%
  select(locationC,year,ARI_mean_150,BSI_mean_150,   
         EVI_mean_150,LAI_mean_150,MSAVI2_mean_150,
         NBR_mean_150,NDMI_mean_150,NDRE_mean_150,NDVI_mean_150,  
         NDWI_mean_150,REIP_mean_150,SAVI_mean_150,  
         SI_mean_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))

sentinel2_2018<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 2 data/Sentinel2_Indices_YERASites_2018.csv", header=TRUE)
sentinel2_2018Filt<-sentinel2_2018%>%
  filter(month==6)%>%
  select(locationC,year,ARI_mean_150,BSI_mean_150,   
         EVI_mean_150,LAI_mean_150,MSAVI2_mean_150,
         NBR_mean_150,NDMI_mean_150,NDRE_mean_150,NDVI_mean_150,  
         NDWI_mean_150,REIP_mean_150,SAVI_mean_150,  
         SI_mean_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))

sentinel2_2019<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 2 data/Sentinel2_Indices_YERASites_2019.csv", header=TRUE)
sentinel2_2019Filt<-sentinel2_2019%>%
  filter(month==6)%>%
  select(locationC,year,ARI_mean_150,BSI_mean_150,   
         EVI_mean_150,LAI_mean_150,MSAVI2_mean_150,
         NBR_mean_150,NDMI_mean_150,NDRE_mean_150,NDVI_mean_150,  
         NDWI_mean_150,REIP_mean_150,SAVI_mean_150,  
         SI_mean_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))

#sentinel2_2020<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 2 data/Sentinel2_Indices_YERASites_2020.csv", header=TRUE)
#sentinel2_2020Filt<-sentinel2_2020%>%
#  filter(month==6)%>%
#  select(locationC,year,ARI_mean_150,BSI_mean_150,   
#         EVI_mean_150,LAI_mean_150,MSAVI2_mean_150,
#         NBR_mean_150,NDMI_mean_150,NDRE_mean_150,NDVI_mean_150,  
#         NDWI_mean_150,REIP_mean_150,SAVI_mean_150,  
#         SI_mean_150)%>%
#  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))

sentinel2_2021<-read.csv("0_data/1_processed/1_Sentinel_Landsat/Sentinel 2 data/Sentinel2_Indices_YERASites_2021.csv", header=TRUE)
sentinel2_2021Filt<-sentinel2_2021%>%
  filter(month==6)%>%
  select(locationC,year,ARI_mean_150,BSI_mean_150,   
         EVI_mean_150,LAI_mean_150,MSAVI2_mean_150,
         NBR_mean_150,NDMI_mean_150,NDRE_mean_150,NDVI_mean_150,  
         NDWI_mean_150,REIP_mean_150,SAVI_mean_150,  
         SI_mean_150)%>%
  filter(locationC %in% levels(as.factor(siteCovFinal$locationC)))

sentinel2_all<-bind_rows(sentinel2_2016Filt,
                         sentinel2_2017Filt,
                         sentinel2_2018Filt,
                         sentinel2_2019Filt,
                         #sentinel2_2020Filt,
                         sentinel2_2021Filt)

#get variables in site major, year minor order
#static NDMI and NBR were top static raw predictors
#static NDMI may do better AIC-wise than yearly NDMI
#yearly NBR may do better AIC-wise than static NBR
yearlyARI<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,ARI_mean_150)%>%
  pivot_wider(names_from=year,values_from=ARI_mean_150)

siteCovFinal$ARI<-yearlyARI$`2016`

yearlyREIP<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,REIP_mean_150)%>%
  pivot_wider(names_from=year,values_from=REIP_mean_150)

siteCovFinal$REIP<-yearlyREIP$`2016`

yearlyNDMI<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,NDMI_mean_150)%>%
  pivot_wider(names_from=year,values_from=NDMI_mean_150)
#These are year-specific values. Get an averaged value across years for each site
staticNDMI<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,NDMI_mean_150)%>%
  group_by(locationC)%>%
  summarise(sNDMI=mean(NDMI_mean_150))

siteCovFinal$NDMI<-yearlyNDMI$`2016`
siteCovFinal$sNDMI<-staticNDMI[,2]

yearlyNDVI<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,NDVI_mean_150)%>%
  pivot_wider(names_from=year,values_from=NDVI_mean_150)#7 years at each of 71 sites

siteCovFinal$NDVI<-yearlyNDVI$`2016`

yearlyNDWI<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,NDWI_mean_150)%>%
  pivot_wider(names_from=year,values_from=NDWI_mean_150)

siteCovFinal$NDWI<-yearlyNDWI$`2016`

yearlyBSI<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,BSI_mean_150)%>%
  pivot_wider(names_from=year,values_from=BSI_mean_150)#7 years at each of 71 sites

siteCovFinal$BSI<-yearlyBSI$`2016`

yearlyNBR<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,NBR_mean_150)%>%
  pivot_wider(names_from=year,values_from=NBR_mean_150)#7 years at each of 71 sites
#These are year-specific values. Get an averaged value across years for each site
staticNBR<-sentinel2_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,NBR_mean_150)%>%
  group_by(locationC)%>%
  summarise(sNBR=mean(NBR_mean_150))
siteCovFinal$sNBR<-staticNBR[,2]

siteCovFinal$NBR<-yearlyNBR$`2016`

#get yearly and static derived RS variables at locations in siteCovFinal
#Dynamic World Layers
dw2016<-read.csv("0_data/1_processed/5_DynamicWorld/ExtractedData2016.csv", header=TRUE)
str(dw2016)
dw2016Filt<-dw2016%>%
  select(locationC,bare,built,crops,flooded_vegetation,trees,water,grass,shrub_and_scrub,snow_and_ice)%>%
  mutate(year=2016,
         woody=trees+shrub_and_scrub)%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  arrange(locationC)

dw2017<-read.csv("0_data/1_processed/5_DynamicWorld/ExtractedData2017.csv", header=TRUE)
str(dw2017)
dw2017Filt<-dw2017%>%
  select(locationC,bare,built,crops,flooded_vegetation,trees,water,grass,shrub_and_scrub,snow_and_ice)%>%
  mutate(year=2017,
         woody=trees+shrub_and_scrub)%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  arrange(locationC)

dw2018<-read.csv("0_data/1_processed/5_DynamicWorld/ExtractedData2018.csv", header=TRUE)
str(dw2018)
dw2018Filt<-dw2018%>%
  select(locationC,bare,built,crops,flooded_vegetation,trees,water,grass,shrub_and_scrub,snow_and_ice)%>%
  mutate(year=2018,
         woody=trees+shrub_and_scrub)%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  arrange(locationC)

dw2019<-read.csv("0_data/1_processed/5_DynamicWorld/ExtractedData2019.csv", header=TRUE)
str(dw2019)
dw2019Filt<-dw2019%>%
  select(locationC,bare,built,crops,flooded_vegetation,trees,water,grass,shrub_and_scrub,snow_and_ice)%>%
  mutate(year=2019,
         woody=trees+shrub_and_scrub)%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  arrange(locationC)

dw2021<-read.csv("0_data/1_processed/5_DynamicWorld/ExtractedData2021.csv", header=TRUE)
str(dw2021)
dw2021Filt<-dw2021%>%
  select(locationC,bare,built,crops,flooded_vegetation,trees,water,grass,shrub_and_scrub,snow_and_ice)%>%
  mutate(year=2021,
         woody=trees+shrub_and_scrub)%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  arrange(locationC)


dw_all<-bind_rows(dw2016Filt,
                  dw2017Filt,
                  dw2018Filt,
                  dw2019Filt,
                  dw2021Filt)

#get variables in site major, year minor order
#bare ground (static) and wet565, elevation, tpi, swi made it into best static derived
#model and were more parsimonious without than with Hedley layer
#bare ground (dynamic), shrub (dynamic), and grass (dynamic) made it into best yearly
#derived model. Bare (static) performed better AIC-wise than bare (dynamic)
yearlyDW_flooded<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,flooded_vegetation)%>%
  pivot_wider(names_from=year,values_from=flooded_vegetation)

yearlyDW_water<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,water)%>%
  pivot_wider(names_from=year,values_from=water)

yearlyDW_woody<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,woody)%>%
  pivot_wider(names_from=year,values_from=woody)

yearlyDW_bare<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,bare)%>%
  pivot_wider(names_from=year,values_from=bare)
#These are year-specific values. Get an averaged value across years for each site
staticDW_bare<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,bare)%>%
  group_by(locationC)%>%
  summarise(sbare=mean(bare))

yearlyDW_grass<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,grass)%>%
  pivot_wider(names_from=year,values_from=grass)
#These are year-specific values. Get an averaged value across years for each site
staticDW_grass<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,grass)%>%
  group_by(locationC)%>%
  summarise(sgrass=mean(grass))

yearlyDW_shrub<-dw_all%>%
  arrange(locationC,year)%>%
  select(locationC,year,shrub_and_scrub)%>%
  pivot_wider(names_from=year,values_from=shrub_and_scrub)


#get more siteCovs for initial occupancy models
siteCovFinal$grass<-yearlyDW_grass$`2016`
siteCovFinal$shrub<-yearlyDW_shrub$`2016`
siteCovFinal$bare<-yearlyDW_bare$`2016`

sbare<-staticDW_bare$sbare
sgrass<-staticDW_grass$sgrass
siteCovFinal$sbare<-staticDW_bare[,2]
siteCovFinal$sgrass<-staticDW_grass[,2]
sDPOLsummer<-staticDPOLsummer[,2]
sNDMI<-staticNDMI[,2]
sNBR<-staticNBR[,2]
sbareSY<-as.matrix(cbind(sbare,
                         sbare,
                         sbare,
                         sbare,
                         sbare))
sgrassSY<-as.matrix(cbind(sgrass,
                          sgrass,
                          sgrass,
                          sgrass,
                          sgrass))
#topography
topo<-read.csv("0_data/1_processed/2_topography/topography150m_June2025.csv", header=TRUE)
topoFilt<-topo%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  mutate(elev=ALOS_dem_raster..MEAN.,
         swi=Topographic.Wetness.Index..MEAN.,
         tpi=Topographic.Position.Index..MEAN.,
         mrvbf=MRVBF..MEAN.)%>%
  select(locationC, elev, swi, tpi, mrvbf)

meanElev<-mean(topoFilt$elev, na.rm=TRUE)
meanSWI<-mean(topoFilt$swi, na.rm=TRUE)
meanTPI<-mean(topoFilt$tpi, na.rm=TRUE)
meanMRVBF<-mean(topoFilt$mrvbf, na.rm=TRUE)

topoFilt<-topoFilt%>%
  mutate(elev=case_when(is.na(elev) ~ meanElev,
                        !is.na(elev) ~ elev))%>%
  mutate(swi=case_when(is.na(swi) ~ meanSWI,
                       !is.na(swi) ~ swi))%>%
  mutate(tpi=case_when(is.na(tpi) ~ meanTPI,
                       !is.na(tpi) ~ tpi))%>%
  mutate(mrvbf=case_when(is.na(mrvbf) ~ meanMRVBF,
                         !is.na(mrvbf) ~ mrvbf))

siteCovFinal$elev<-topoFilt$elev
siteCovFinal$swi<-topoFilt$swi
siteCovFinal$tpi<-topoFilt$tpi
siteCovFinal$mrvbf<-topoFilt$mrvbf

Elev<-siteCovFinal$elev
Y_elev<-as.matrix(cbind(Elev,Elev,Elev,Elev,Elev))
SWI<-siteCovFinal$swi
Y_swi<-as.matrix(cbind(SWI,SWI,SWI,SWI,SWI))
TPI<-siteCovFinal$tpi
Y_tpi<-as.matrix(cbind(TPI,TPI,TPI,TPI,TPI))
MRVBF<-siteCovFinal$mrvbf
Y_mrvbf<-as.matrix(cbind(MRVBF,MRVBF,MRVBF,MRVBF,MRVBF))


wet<-read.csv("0_data/1_processed/3_wetlands/wetlandProb_uplandDist.csv", header=TRUE)
wet<-wet%>%
  filter(locationC %in% siteCovFinal$locationC)%>%
  select(locationC, wetlandProb_150m, wetlandProb_565m, distUpland)%>%
  arrange(locationC)
cor(wet$wetlandProb_150m, wet$distUpland)#0.65

siteCovFinal$wetlandProb_150m<-wet$wetlandProb_150m
siteCovFinal$wetlandProb_565m<-wet$wetlandProb_565m
siteCovFinal$distUpland<-wet$distUpland

Wet565<-wet$wetlandProb_565m
Y_wet565<-as.matrix(cbind(Wet565,Wet565,Wet565,Wet565,Wet565))



umf<-unmarkedMultFrame(y=obsFiltFinal,
                       siteCovs = siteCovFinal,
                       obsCovs=list(time=matrix(4,115,25)),#8 years*5 rounds
                       yearlySiteCovs=list(Y_habSuit=yearlyHabSuit4Class[,2:6],
                                           Y_latitude=yearlyLatitude,
                                           Y_longitude=yearlyLongitude,
                                           Y_elev=Y_elev,
                                           Y_swi=Y_swi,
                                           Y_tpi=Y_tpi,
                                           Y_mrvbf=Y_mrvbf,
                                           #Y_wet150=Y_wet150,
                                           Y_wet565=Y_wet565,
                                           Y_DW_bare=yearlyDW_bare[,2:6],
                                           Y_DW_grass=yearlyDW_grass[,2:6],
                                           Y_DW_flooded=yearlyDW_flooded[,2:6],
                                           Y_DW_water=yearlyDW_water[,2:6],
                                           Y_DW_woody=yearlyDW_woody[,2:6],
                                           S_DW_grass=sgrassSY,
                                           Y_DW_shrub=yearlyDW_shrub[,2:6],
                                           Y_ARI=yearlyARI[,2:6],
                                           Y_BSI=yearlyBSI[,2:6],
                                           Y_DeltaVH=yearlyDeltaVH[,2:6],
                                           sDPOLsummer=as.matrix(cbind(sDPOLsummer,sDPOLsummer,sDPOLsummer,
                                                                       sDPOLsummer,sDPOLsummer)),
                                           sNDMI=as.matrix(cbind(sNDMI,sNDMI,sNDMI,
                                                                 sNDMI,sNDMI)),
                                           Y_DPOLsummer=yearlyDPOLsummer[,2:6],
                                           Y_NBR=yearlyNBR[,2:6],
                                           sNBR=as.matrix(cbind(sNBR,sNBR,sNBR,
                                                                 sNBR,sNBR)),
                                           Y_NDMI=yearlyNDMI[,2:6],
                                           Y_NDVI=yearlyNDVI[,2:6],
                                           Y_NDWI=yearlyNDWI[,2:6],
                                           Y_REIP=yearlyREIP[,2:6]),
                       numPrimary=5) 

#Scale predictors and create nonlinear terms
umf@siteCovs$elev.s<-scale(umf@siteCovs$elev, center = TRUE, scale = TRUE)
umf@siteCovs$elev.s2<-umf@siteCovs$elev.s^2
umf@siteCovs$elev.sqrt<-sqrt(umf@siteCovs$elev)

umf@siteCovs$lat.s<-scale(umf@siteCovs$lat, center = TRUE, scale = TRUE)
umf@siteCovs$lat.s2<-umf@siteCovs$lat.s^2
umf@siteCovs$lat.sqrt<-sqrt(umf@siteCovs$lat)

umf@siteCovs$swi.s<-scale(umf@siteCovs$swi, center = TRUE, scale = TRUE)
umf@siteCovs$swi.s2<-umf@siteCovs$swi.s^2
umf@siteCovs$swi.sqrt<-sqrt(umf@siteCovs$swi)

umf@siteCovs$tpi.s<-scale(umf@siteCovs$tpi, center = TRUE, scale = TRUE)
umf@siteCovs$tpi.s2<-umf@siteCovs$tpi.s^2
umf@siteCovs$tpi.sqrt<-sqrt(umf@siteCovs$tpi)

umf@siteCovs$wet565.s<-scale(umf@siteCovs$wetlandProb_565m, center = TRUE, scale = TRUE)
umf@siteCovs$wet565.s2<-umf@siteCovs$wet565.s^2
umf@siteCovs$wet565.sqrt<-sqrt(umf@siteCovs$wetlandProb_565m)

#umf@siteCovs$DPOLsummer.s<-scale(umf@siteCovs$DPOLsummer, center = TRUE, scale = TRUE)[,1]
#umf@siteCovs$DPOLsummer.s2<-umf@siteCovs$DPOLsummer.s^2
#umf@siteCovs$DPOLsummer.sqrt<-sqrt(umf@siteCovs$DPOLsummer)

umf@siteCovs$sDPOLsummer.s<-scale(umf@siteCovs$sDPOLsummer, center = TRUE, scale = TRUE)
umf@siteCovs$sDPOLsummer.s2<-umf@siteCovs$sDPOLsummer.s^2
umf@siteCovs$sDPOLsummer.sqrt<-sqrt(umf@siteCovs$sDPOLsummer)

umf@siteCovs$DeltaVH.s<-scale(umf@siteCovs$DeltaVH, center = TRUE, scale = TRUE)
umf@siteCovs$DeltaVH.s2<-umf@siteCovs$DeltaVH.s^2
umf@siteCovs$DeltaVH.sqrt<-sqrt(umf@siteCovs$DeltaVH)

umf@siteCovs$ARI.s<-scale(umf@siteCovs$ARI, center = TRUE, scale = TRUE)
umf@siteCovs$ARI.s2<-umf@siteCovs$ARI.s^2
umf@siteCovs$ARI.sqrt<-sqrt(umf@siteCovs$ARI)

umf@siteCovs$BSI.s<-scale(umf@siteCovs$BSI, center = TRUE, scale = TRUE)
umf@siteCovs$BSI.s2<-umf@siteCovs$BSI.s^2
umf@siteCovs$BSI.sqrt<-sqrt(umf@siteCovs$BSI)

umf@siteCovs$NBR.s<-scale(umf@siteCovs$NBR, center = TRUE, scale = TRUE)
umf@siteCovs$NBR.s2<-umf@siteCovs$NBR.s^2
umf@siteCovs$NBR.sqrt<-sqrt(umf@siteCovs$NBR)

umf@siteCovs$sNBR.s<-scale(umf@siteCovs$sNBR, center = TRUE, scale = TRUE)
umf@siteCovs$sNBR.s2<-umf@siteCovs$sNBR.s^2
umf@siteCovs$sNBR.sqrt<-sqrt(umf@siteCovs$sNBR)

umf@siteCovs$REIP.s<-scale(umf@siteCovs$REIP, center = TRUE, scale = TRUE)
umf@siteCovs$REIP.s2<-umf@siteCovs$REIP.s^2
umf@siteCovs$REIP.sqrt<-sqrt(umf@siteCovs$REIP)

umf@siteCovs$NDMI.s<-scale(umf@siteCovs$NDMI, center = TRUE, scale = TRUE)
umf@siteCovs$NDMI.s2<-umf@siteCovs$NDMI.s^2
umf@siteCovs$NDMI.sqrt<-sqrt(umf@siteCovs$NDMI)

umf@siteCovs$sNDMI.s<-scale(umf@siteCovs$sNDMI, center = TRUE, scale = TRUE)
umf@siteCovs$sNDMI.s2<-umf@siteCovs$sNDMI.s^2
umf@siteCovs$sNDMI.sqrt<-sqrt(umf@siteCovs$sNDMI)

umf@siteCovs$NDVI.s<-scale(umf@siteCovs$NDVI, center = TRUE, scale = TRUE)
umf@siteCovs$NDVI.s2<-umf@siteCovs$NDVI.s^2
umf@siteCovs$NDVI.sqrt<-sqrt(umf@siteCovs$NDVI)

umf@siteCovs$NDWI.s<-scale(umf@siteCovs$NDWI, center = TRUE, scale = TRUE)
umf@siteCovs$NDWI.s2<-umf@siteCovs$NDWI.s^2
umf@siteCovs$NDWI.sqrt<-sqrt(umf@siteCovs$NDWI)

umf@siteCovs$bare.s<-scale(umf@siteCovs$bare, center = TRUE, scale = TRUE)
umf@siteCovs$bare.s2<-umf@siteCovs$bare.s^2
umf@siteCovs$bare.sqrt<-sqrt(umf@siteCovs$bare)

umf@siteCovs$grass.s<-scale(umf@siteCovs$grass, center = TRUE, scale = TRUE)
umf@siteCovs$grass.s2<-umf@siteCovs$grass.s^2
umf@siteCovs$grass.sqrt<-sqrt(umf@siteCovs$grass)

umf@siteCovs$sgrass.s<-scale(umf@siteCovs$sgrass, center = TRUE, scale = TRUE)
umf@siteCovs$sgrass.s2<-umf@siteCovs$sgrass.s^2
umf@siteCovs$sgrass.sqrt<-sqrt(umf@siteCovs$sgrass)

umf@siteCovs$shrub.s<-scale(umf@siteCovs$shrub, center = TRUE, scale = TRUE)
umf@siteCovs$shrub.s2<-umf@siteCovs$shrub.s^2
umf@siteCovs$shrub.sqrt<-sqrt(umf@siteCovs$shrub)

#umf@yearlySiteCovs$Y_distUpland.s<-scale(umf@yearlySiteCovs$Y_distUpland, center = TRUE, scale = TRUE)
#umf@yearlySiteCovs$Y_distUpland.s2<-umf@yearlySiteCovs$Y_distUpland.s^2
#umf@yearlySiteCovs$Y_distUpland.sqrt<-sqrt(umf@yearlySiteCovs$Y_distUpland)

#umf@yearlySiteCovs$Y_wet150.s<-scale(umf@yearlySiteCovs$Y_wet150, center = TRUE, scale = TRUE)
#umf@yearlySiteCovs$Y_wet150.s2<-umf@yearlySiteCovs$Y_wet150.s^2
#umf@yearlySiteCovs$Y_wet150.sqrt<-sqrt(umf@yearlySiteCovs$Y_wet150)

umf@yearlySiteCovs$Y_wet565.s<-scale(umf@yearlySiteCovs$Y_wet565, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$Y_wet565.s2<-umf@yearlySiteCovs$Y_wet565.s^2
umf@yearlySiteCovs$Y_wet565.sqrt<-sqrt(umf@yearlySiteCovs$Y_wet565)

umf@yearlySiteCovs$Y_elev.s<-scale(umf@yearlySiteCovs$Y_elev, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$Y_elev.s2<-umf@yearlySiteCovs$Y_elev.s^2
umf@yearlySiteCovs$Y_elev.sqrt<-sqrt(umf@yearlySiteCovs$Y_elev)

umf@yearlySiteCovs$Y_latitude.s<-scale(umf@yearlySiteCovs$Y_latitude, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$Y_latitude.s2<-umf@yearlySiteCovs$Y_latitude.s^2
umf@yearlySiteCovs$Y_latitude.sqrt<-sqrt(umf@yearlySiteCovs$Y_latitude)


umf@yearlySiteCovs$Y_swi.s<-scale(umf@yearlySiteCovs$Y_swi, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$Y_swi.s2<-umf@yearlySiteCovs$Y_swi.s^2
umf@yearlySiteCovs$Y_swi.sqrt<-sqrt(umf@yearlySiteCovs$Y_swi)

umf@yearlySiteCovs$Y_tpi.s<-scale(umf@yearlySiteCovs$Y_tpi, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$Y_tpi.s2<-umf@yearlySiteCovs$Y_tpi.s^2
umf@yearlySiteCovs$Y_tpi.sqrt<-sqrt(umf@yearlySiteCovs$Y_tpi)

#umf@yearlySiteCovs$Y_mrvbf.s<-scale(umf@yearlySiteCovs$Y_mrvbf, center = TRUE, scale = TRUE)
#umf@yearlySiteCovs$Y_mrvbf.s2<-umf@yearlySiteCovs$Y_mrvbf.s^2
#umf@yearlySiteCovs$Y_mrvbf.sqrt<-sqrt(umf@yearlySiteCovs$Y_mrvbf)

umf@yearlySiteCovs$sDPOLsummer.s<-scale(umf@yearlySiteCovs$sDPOLsummer, center = TRUE, scale = TRUE)[,1]
umf@yearlySiteCovs$sDPOLsummer.s2<-umf@yearlySiteCovs$sDPOLsummer.s^2
umf@yearlySiteCovs$sDPOLsummer.sqrt<-sqrt(umf@yearlySiteCovs$sDPOLsummer)

umf@yearlySiteCovs$DeltaVH.s<-scale(umf@yearlySiteCovs$Y_DeltaVH, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$DeltaVH.s2<-umf@yearlySiteCovs$DeltaVH.s^2
umf@yearlySiteCovs$DeltaVH.sqrt<-sqrt(umf@yearlySiteCovs$Y_DeltaVH)

#umf@yearlySiteCovs$ARI.s<-scale(umf@yearlySiteCovs$Y_ARI, center = TRUE, scale = TRUE)[,1]
#umf@yearlySiteCovs$ARI.s2<-umf@yearlySiteCovs$ARI.s^2
#umf@yearlySiteCovs$ARI.sqrt<-sqrt(umf@yearlySiteCovs$Y_ARI)

umf@yearlySiteCovs$BSI.s<-scale(umf@yearlySiteCovs$Y_BSI, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$BSI.s2<-umf@yearlySiteCovs$BSI.s^2
umf@yearlySiteCovs$BSI.sqrt<-sqrt(umf@yearlySiteCovs$Y_BSI)

umf@yearlySiteCovs$NBR.s<-scale(umf@yearlySiteCovs$Y_NBR, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$NBR.s2<-umf@yearlySiteCovs$NBR.s^2
umf@yearlySiteCovs$NBR.sqrt<-sqrt(umf@yearlySiteCovs$Y_NBR)

umf@yearlySiteCovs$sNBR.s<-scale(umf@yearlySiteCovs$sNBR, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$sNBR.s2<-umf@yearlySiteCovs$sNBR.s^2
umf@yearlySiteCovs$sNBR.sqrt<-sqrt(umf@yearlySiteCovs$sNBR)

umf@yearlySiteCovs$REIP.s<-scale(umf@yearlySiteCovs$Y_REIP, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$REIP.s2<-umf@yearlySiteCovs$REIP.s^2
umf@yearlySiteCovs$REIP.sqrt<-sqrt(umf@yearlySiteCovs$Y_REIP)

umf@yearlySiteCovs$NDMI.s<-scale(umf@yearlySiteCovs$Y_NDMI, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$NDMI.s2<-umf@yearlySiteCovs$NDMI.s^2
umf@yearlySiteCovs$NDMI.sqrt<-sqrt(umf@yearlySiteCovs$Y_NDMI)

umf@yearlySiteCovs$sNDMI.s<-scale(umf@yearlySiteCovs$sNDMI, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$sNDMI.s2<-umf@yearlySiteCovs$sNDMI.s^2
umf@yearlySiteCovs$sNDMI.sqrt<-sqrt(umf@yearlySiteCovs$sNDMI)

umf@yearlySiteCovs$bare.s<-scale(umf@yearlySiteCovs$Y_DW_bare, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$bare.s2<-umf@yearlySiteCovs$bare.s^2
umf@yearlySiteCovs$bare.sqrt<-sqrt(umf@yearlySiteCovs$Y_DW_bare)

umf@yearlySiteCovs$grass.s<-scale(umf@yearlySiteCovs$Y_DW_grass, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$grass.s2<-umf@yearlySiteCovs$grass.s^2
umf@yearlySiteCovs$grass.sqrt<-sqrt(umf@yearlySiteCovs$Y_DW_grass)

umf@yearlySiteCovs$sgrass.s<-scale(umf@yearlySiteCovs$S_DW_grass, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$sgrass.s2<-umf@yearlySiteCovs$sgrass.s^2
umf@yearlySiteCovs$sgrass.sqrt<-sqrt(umf@yearlySiteCovs$S_DW_grass)

umf@yearlySiteCovs$shrub.s<-scale(umf@yearlySiteCovs$Y_DW_shrub, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$shrub.s2<-umf@yearlySiteCovs$shrub.s^2
umf@yearlySiteCovs$shrub.sqrt<-sqrt(umf@yearlySiteCovs$Y_DW_shrub)


umf@yearlySiteCovs$NDVI.s<-scale(umf@yearlySiteCovs$Y_NDVI, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$NDVI.s2<-umf@yearlySiteCovs$NDVI.s^2
umf@yearlySiteCovs$NDVI.sqrt<-sqrt(umf@yearlySiteCovs$Y_NDVI)

umf@yearlySiteCovs$NDWI.s<-scale(umf@yearlySiteCovs$Y_NDWI, center = TRUE, scale = TRUE)
umf@yearlySiteCovs$NDWI.s2<-umf@yearlySiteCovs$NDWI.s^2
umf@yearlySiteCovs$NDWI.sqrt<-sqrt(umf@yearlySiteCovs$Y_NDWI)


umf@siteCovs$HabSuit4ClassNumeric<-as.factor(umf@siteCovs$HabSuit4ClassNumeric)
umf@yearlySiteCovs$Y_habSuit<-as.factor(umf@yearlySiteCovs$Y_habSuit)

model1<-colext(psiformula= ~HabSuit4ClassNumeric, 
               gammaformula =  ~ Y_habSuit, 
               epsilonformula = ~ Y_habSuit,
               pformula = ~ 1, umf)
summary(model1)#AIC: 1682.768 (Null model)

mb.gof.test(model1, nsim = 1000, plot.hist = TRUE,
            report = NULL, parallel = TRUE,
            ncores=2, cex.axis = 1, cex.lab = 1, cex.main = 1,
            lwd = 1, plot.seasons = FALSE)
#Goodness-of-fit for dynamic occupancy model
#Number of seasons:  5 
#Chi-square statistic:
#  Season 1 Season 2 Season 3 Season 4 Season 5 
#87.0703 104.1541  35.4833  31.4974  61.1523 
#Total chi-square = 319.3575 
#Number of bootstrap samples = 1000
#P-value = 0
#Quantiles of bootstrapped statistics:
#  0%  25%  50%  75% 100% 
#112  155  169  187  315 
#Estimate of c-hat = 1.85 

cor(siteCovFinal$NDMI, siteCovFinal$NDWI)
#NDVI and NDWI not correlated (0.02)
cor(siteCovFinal$NDMI, siteCovFinal$NBR)
#NDMI and NBR strongly positively correlated (0.85)
cor(siteCovFinal$NDMI, siteCovFinal$BSI)
#NDMI and BSI strongly negatively correlated (-0.91)
cor(siteCovFinal$NBR, siteCovFinal$BSI)
#NBR and BSI strongly negatively correlated (-0.95)
#pick one (NBR, BSI, NDMI)

#parallel processing and using dredge didn't work, so dropping it

#RS model without Hedley layer
RSonlyModel<-colext(psiformula= ~NDMI.s+NDMI.s2+DeltaVH.s+DeltaVH.s2+sNBR.s+bare.s+sgrass.s+sgrass.s2+lat.sqrt, #either keep NDMI or NBR
                    gammaformula =  ~ sDPOLsummer.s+Y_swi.sqrt, 
                    epsilonformula = ~ NDMI.s+DeltaVH.s+DeltaVH.s2+sDPOLsummer.s+Y_tpi.s+Y_latitude.sqrt+shrub.s,
                    pformula = ~ 1, umf)#AIC: 1576.832
#Drop eps ~ NDMI, TPI, shrub, gamma ~ DPOL, psi ~ NBR, DeltaVHs2, bare

RSonlyModel<-colext(psiformula= ~NDMI.s+NDMI.s2+DeltaVH.s+sgrass.s+sgrass.s2+lat.sqrt, #either keep NDMI or NBR
                    gammaformula =  ~ Y_swi.sqrt, 
                    epsilonformula = ~ DeltaVH.s+DeltaVH.s2+sDPOLsummer.s+Y_latitude.sqrt,
                    pformula = ~ 1, umf)#AIC: 1575.717

mb.gof.test(RSonlyModel, nsim = 1000, plot.hist = TRUE,
            report = NULL, parallel = TRUE,
            ncores=2, cex.axis = 1, cex.lab = 1, cex.main = 1,
            lwd = 1, plot.seasons = FALSE)
#Chi-square statistic:
#Season 1 Season 2 Season 3 Season 4 Season 5 
#87.7963  87.0103  35.1685  32.5430  62.2708 
#Total chi-square = 304.7889 
#Number of bootstrap samples = 1000
#P-value = 0.009
#Quantiles of bootstrapped statistics:
#  0%  25%  50%  75% 100% 
#121  154  169  187  451 
#Estimate of c-hat = 1.74 

NullModel<-colext(psiformula= ~1, 
                    gammaformula =  ~ 1, 
                    epsilonformula = ~ 1,
                    pformula = ~ 1, umf)#AIC: 1690.285

mb.gof.test(NullModel, nsim = 1000, plot.hist = TRUE,
            report = NULL, parallel = TRUE,
            ncores=2, cex.axis = 1, cex.lab = 1, cex.main = 1,
            lwd = 1, plot.seasons = FALSE)
#Chi-square statistic:
#Season 1 Season 2 Season 3 Season 4 Season 5 
#86.3005 101.9738  36.0336  32.9264  62.6683 
#Total chi-square = 319.9025 
#Number of bootstrap samples = 1000
#P-value = 0
#Quantiles of bootstrapped statistics:
#  0%  25%  50%  75% 100% 
#121  158  173  188  262 
#Estimate of c-hat = 1.84 

#"Full Model"
FullModel<-colext(psiformula= ~HabSuit4ClassNumeric+NDMI.s+NDMI.s2+DeltaVH.s+sgrass.s+sgrass.s2+lat.sqrt, 
                  gammaformula =  ~ Y_swi.sqrt, 
                  epsilonformula = ~ Y_habSuit+DeltaVH.s+DeltaVH.s2+sDPOLsummer.s+Y_latitude.sqrt,
                  pformula = ~ 1, umf)#AIC: 1570.577
#Drop psi ~ HabSuit4ClassNumeric?

FullModel<-colext(psiformula= ~NDMI.s+NDMI.s2+DeltaVH.s+sgrass.s+sgrass.s2+lat.sqrt, 
                  gammaformula =  ~ Y_swi.sqrt, 
                  epsilonformula = ~ Y_habSuit+DeltaVH.s+DeltaVH.s2+sDPOLsummer.s+Y_latitude.sqrt,
                  pformula = ~ 1, umf)#AIC: 1571.606

#Call:
#colext(psiformula = ~NDMI.s + NDMI.s2 + DeltaVH.s + sgrass.s + 
#         sgrass.s2 + lat.sqrt, gammaformula = ~Y_swi.sqrt, epsilonformula = ~Y_habSuit + 
#         DeltaVH.s + DeltaVH.s2 + sDPOLsummer.s + Y_latitude.sqrt, 
#       pformula = ~1, data = umf)

#Initial (logit-scale):
#  Estimate     SE     z P(>|z|)
#(Intercept)    98.92 51.172  1.93  0.0532
#NDMI.s         -1.09  0.567 -1.92  0.0549
#NDMI.s2        -1.45  0.581 -2.49  0.0126
#DeltaVH.s      -1.12  0.491 -2.28  0.0226
#sgrass.s        2.79  1.204  2.31  0.0206
#sgrass.s2       3.29  1.344  2.45  0.0144
#lat.sqrt      -13.09  6.779 -1.93  0.0535

#Colonization (logit-scale):
#  Estimate   SE     z  P(>|z|)
#(Intercept)    -17.1 5.19 -3.30 0.000963
#Y_swi.sqrt       5.2 1.66  3.14 0.001688

#Extinction (logit-scale):
#  Estimate     SE      z  P(>|z|)
#(Intercept)      -66.139 26.101 -2.534 0.011277
#Y_habSuit2         1.330  0.726  1.832 0.066917
#Y_habSuit3         1.722  0.664  2.592 0.009545
#Y_habSuit4         0.226  0.677  0.333 0.738786
#DeltaVH.s          0.652  0.300  2.173 0.029802
#DeltaVH.s2         1.014  0.279  3.631 0.000282
#sDPOLsummer.s      1.391  0.398  3.500 0.000465
#Y_latitude.sqrt    8.602  3.451  2.492 0.012693

#Detection (logit-scale):
#  Estimate     SE    z  P(>|z|)
#0.472 0.0727 6.49 8.46e-11

#AIC: 1571.606 
#Number of sites: 115

mb.gof.test(FullModel, nsim = 1000, plot.hist = TRUE,
            report = NULL, parallel = TRUE,
            ncores=2, cex.axis = 1, cex.lab = 1, cex.main = 1,
            lwd = 1, plot.seasons = FALSE)
#Goodness-of-fit for dynamic occupancy model
#Number of seasons:  5 
#Chi-square statistic:
#  Season 1 Season 2 Season 3 Season 4 Season 5 
#88.0588  88.9277  34.9721  31.8075  62.6698 
#Total chi-square = 306.4358 
#Number of bootstrap samples = 1000
#P-value = 0.003
#Quantiles of bootstrapped statistics:
#  0%  25%  50%  75% 100% 
#113  153  168  186  391 
#Estimate of c-hat = 1.76  

#Get estimates of uncertainty in yearly occu. probability via 
#nonparametric bootstrapping
#use bootstrap to get estimates of psi (occu.) from derived parameter estimates

bootModel100x<-nonparboot(FullModel, B=100)
str(bootModel100x@projected)
#num [1:2, 1:8, 1:146] 0.46 0.54 0.694 0.306 0.688 ...
#this is a 3d array whose number is equal to 146(#sites)*8(#years)*2(1st vector for prob. absence,
#2nd vector for prob. occu.)
#http://www.statmethods.net/advstats/bootstrapping.html for a description of the bootstrap object structure
#boot( ) calls the statistic function R times. Each time, it generates a set of 
#random indices, with replacement, from the integers 1:nrow(data). These indices 
#are used within the statistic function to select a sample. The statistics are 
#calculated on the sample and the results are accumulated in the bootobject. The 
#bootobject structure includes

#basic bootstrap object element description 
#t0           The observed values of k statistics applied to the orginal data.  
#t            An R x k matrix where each row is a bootstrap replicate of the k statistics. 

#You can access these as bootobject$t0 and bootobject$t.

#Once you generate the bootstrap samples, print(bootobject) and plot(bootobject) can be used to examine the 
#results. If the results look reasonable, you can use boot.ci( ) function to obtain confidence intervals for 
#the statistic(s). 

bootModel100x@projected[2,,1]
#this is how you call up predicted probability of occu. based on the bootstrap samples for site 1
#in the colext unmarked Frame in each of the 7 years
#Yellow Rail predicted occu. probability has declined at this site over time.
bootModel100x@projected[1,,1]
#this is how you call up predicted probability that site is unoccupied based on the original data for site 1
#in the colext unmarked Frame
#These results are equivalent to 1 minus bootModel100x@projected[2,,1]

bootModel100x@projected[2,,9]#this is how you call up predicted probability of occu. based on the bootstrap samples for site 9
#in the colext unmarked Frame in each of the 7 years
bootModel100x@projected[2,,]#this is how you call up predicted probability of occu. based on the bootstrap samples 
#in the colext unmarked Frame, for all sites in each of the 7 years. 
#a 208 x 7 matrix
smoothed(bootModel100x)[2,] 
#average occu. probability in each year across all 208 sites
bootModel100x@projected.mean.bsse#the standard errors for projected occu.. Note that SE is same for probability of
#presence and probability of absence
bootModel100x@projected.mean.bsse[2,]#Also note that there is 1 SE calculated for each year but not for each site
#unlike probability of occu.

#Get regional projected changes in occu.
umf@siteCovs%>%
  select(locationC,clusterID)
#row numbers indicate how sites in a specific
#region are numbered in bootModel100x@projected

#Cluster 1 (formerly 3_6)
cluster3_6List<-list()#Audet
for (j in c(110:115)){
  siteRownum<-j
  m.cluster3_6List<-bootModel100x@projected[2,,j]
  m.cluster3_6List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster3_6List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster3_6List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster3_6List,
                                  l95=m.cluster3_6List_l95,
                                  u95=m.cluster3_6List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster3_6<-do.call(rbind, cluster3_6List)

Occucluster3_6 <- ggplot(data=cluster3_6, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 1")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster3_6 (Audet Lake)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(-0.25,1.25)+xlim(2016,2021)

#Cluster 2
cluster4_5List<-list()#West Mine
for (j in c(45:59,61,75,78,80:81,86:89,93,97:99,101:105,107:109)){
  siteRownum<-j
  m.cluster4_5List<-bootModel100x@projected[2,,j]
  m.cluster4_5List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster4_5List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster4_5List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster4_5List,
                                  l95=m.cluster4_5List_l95,
                                  u95=m.cluster4_5List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster4_5<-do.call(rbind, cluster4_5List)

Occucluster4_5 <- ggplot(data=cluster4_5, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 2")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster4_5 (West Mine)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(0,1)+xlim(2016,2021)

umf@siteCovs%>%
  select(locationC,clusterID)
#row numbers indicate how sites in a specific
#region are numbered in bootModel100x@projected

#Cluster 3
cluster7_5List<-list()#East Mine
for (j in c(60,62:74,76:77,79,82:85,90:92,94:96,100,106)){
  siteRownum<-j
  m.cluster7_5List<-bootModel100x@projected[2,,j]
  m.cluster7_5List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster7_5List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster7_5List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster7_5List,
                                  l95=m.cluster7_5List_l95,
                                  u95=m.cluster7_5List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster7_5<-do.call(rbind, cluster7_5List)

Occucluster7_5 <- ggplot(data=cluster7_5, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 3")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster7_5 (East Mine)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(0,1)+xlim(2016,2021)

#Cluster 4 (No sites with 3+ years of visits between 2016 - 2021)
# cluster2_10List<-list()#Gipsy Lake
# for (j in c(47:49)){
#   siteRownum<-j
#   m.cluster2_10List<-bootModel100x@projected[2,,j]
#   m.cluster2_10List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
#   m.cluster2_10List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
#   cluster2_10List[[j]]<-data.frame(site=siteRownum,
#                                    occ=m.cluster2_10List,
#                                    l95=m.cluster2_10List_l95,
#                                    u95=m.cluster2_10List_u95,
#                                    year=c(2013,2014,2015,2016,2017,2018,2019,2021))
# }
# cluster2_10<-do.call(rbind, cluster2_10List)
# 
# Occucluster2_10 <- ggplot(data=cluster2_10, aes(x=year, y=occ, group=site)) +
#   geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+
#   geom_line(aes(x=year, y=occ, group=site), colour="blue")+
#   my.theme+ggtitle("Cluster 4")+xlab("Year")+ylab("Predicted occu.")+
#   #my.theme+ggtitle("Cluster2_10 (Gipsy Lake)")+xlab("Year")+ylab("Predicted occu.")+
#   ylim(-0.25,1.25)+xlim(2013,2021)


#Cluster 5
cluster3_1List<-list()#881 between Quigley and Chard
for (j in c(33:44)){
  siteRownum<-j
  m.cluster3_1List<-bootModel100x@projected[2,,j]
  m.cluster3_1List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster3_1List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster3_1List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster3_1List,
                                  l95=m.cluster3_1List_l95,
                                  u95=m.cluster3_1List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster3_1<-do.call(rbind, cluster3_1List)

Occucluster3_1 <- ggplot(data=cluster3_1, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+ 
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 5")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster3_1 (Highway 881)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(-0.25,1.25)+xlim(2016,2021)


#Cluster 6

cluster7_8List<-list()#Lac La Biche
for (j in c(23:32)){
  siteRownum<-j
  m.cluster7_8List<-bootModel100x@projected[2,,j]
  m.cluster7_8List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster7_8List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster7_8List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster7_8List,
                                  l95=m.cluster7_8List_l95,
                                  u95=m.cluster7_8List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster7_8<-do.call(rbind, cluster7_8List)

Occucluster7_8 <- ggplot(data=cluster7_8, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 6")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster7_8 (Lac La Biche)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(-0.25,1.25)+xlim(2016,2021)


#Cluster 7
cluster3_8List<-list()#North of La Corey
for (j in c(16:22)){
  siteRownum<-j
  m.cluster3_8List<-bootModel100x@projected[2,,j]
  m.cluster3_8List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster3_8List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster3_8List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster3_8List,
                                  l95=m.cluster3_8List_l95,
                                  u95=m.cluster3_8List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster3_8<-do.call(rbind, cluster3_8List)

Occucluster3_8 <- ggplot(data=cluster3_8, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), fill="blue", alpha=0.2)+
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 7")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster3_8 (North of La Corey)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(-0.25,1.25)+xlim(2016,2021)

umf@siteCovs%>%
  select(locationC,clusterID)
#Cluster 8
cluster2_8List<-list()#Imperial Oil/Cold Lake
for (j in c(1:15)){
  siteRownum<-j
  m.cluster2_8List<-bootModel100x@projected[2,,j]
  m.cluster2_8List_l95<-bootModel100x@projected[2,,j]-1.96*bootModel100x@projected.mean.bsse[2,]
  m.cluster2_8List_u95<-bootModel100x@projected[2,,j]+1.96*bootModel100x@projected.mean.bsse[2,]
  cluster2_8List[[j]]<-data.frame(site=siteRownum,
                                  occ=m.cluster2_8List,
                                  l95=m.cluster2_8List_l95,
                                  u95=m.cluster2_8List_u95,
                                  year=c(2016,2017,2018,2019,2021))
}
cluster2_8<-do.call(rbind, cluster2_8List)

Occucluster2_8 <- ggplot(data=cluster2_8, aes(x=year, y=occ, group=site)) +
  geom_ribbon(aes(x=year, ymin=l95, ymax=u95, group=site), alpha = 0.2, fill = "blue")+
  geom_line(aes(x=year, y=occ, group=site), colour="blue")+
  my.theme+ggtitle("Cluster 8")+xlab("Year")+ylab("Predicted occu.")+
  #my.theme+ggtitle("Cluster2_8 (Imperial Oil/Cold Lake)")+xlab("Year")+ylab("Predicted occu.")+
  ylim(-0.25,1.25)+xlim(2016,2021)

#Need cluster 9? (4_8) still


multipanelPlot<-grid.arrange(Occucluster3_6,#cluster 1 (Audet Lake)
                             Occucluster4_5,#cluster 2 (West Mine)
                             Occucluster7_5,#cluster 3 (East Mine)
                             #Occucluster2_10,#cluster 4 (Gipsy Lake)
                             Occucluster3_1,#cluster 5 (Highway 881)
                             Occucluster7_8,#cluster 6 (Lac La Biche)
                             Occucluster3_8,#cluster 7 (N of La Corey)
                             Occucluster2_8,#cluster 8 (Imperial Oil/Cold Lake)
                             nrow=3,ncol=3)
ggsave(filename="2_outputs/1_unmarked_outputs/4_November_2025/Hedley 2016 2021/occu.ByRegion2016_2021_HedleyXHybridRS.png", plot=multipanelPlot, width=16, height=12, units="in", dpi=300)

FullModelWithoutLat<-colext(psiformula= ~NDMI.s+NDMI.s2+DeltaVH.s+sgrass.s+sgrass.s2, 
                  gammaformula =  ~ Y_swi.sqrt, 
                  epsilonformula = ~ Y_habSuit+DeltaVH.s+DeltaVH.s2+sDPOLsummer.s,
                  pformula = ~ 1, umf)#AIC: 1579.463
#Initial (logit-scale):
#Estimate    SE      z  P(>|z|)
#(Intercept)    0.211 0.691  0.305 0.760550
#NDMI.s        -0.690 0.440 -1.568 0.116853
#NDMI.s2       -1.049 0.464 -2.262 0.023683
#DeltaVH.s     -1.562 0.431 -3.621 0.000293
#sgrass.s       2.494 1.016  2.455 0.014071
#sgrass.s2      3.299 1.299  2.540 0.011074

#Colonization (logit-scale):
#  Estimate   SE     z P(>|z|)
#(Intercept)   -16.69 5.15 -3.24 0.00120
#Y_swi.sqrt      5.06 1.65  3.07 0.00211

#Extinction (logit-scale):
#  Estimate    SE      z  P(>|z|)
#(Intercept)     -1.428 0.493 -2.895 0.003786
#Y_habSuit2       1.502 0.696  2.158 0.030924
#Y_habSuit3       2.014 0.666  3.025 0.002485
#Y_habSuit4       0.340 0.668  0.509 0.610758
#DeltaVH.s        0.871 0.285  3.054 0.002258
#DeltaVH.s2       0.988 0.255  3.870 0.000109
#sDPOLsummer.s    1.524 0.411  3.710 0.000207

#Detection (logit-scale):
#  Estimate     SE    z  P(>|z|)
#0.478 0.0723 6.62 3.69e-11
mb.gof.test(FullModelWithoutLat, nsim = 1000, plot.hist = TRUE,
            report = NULL, parallel = TRUE,
            ncores=2, cex.axis = 1, cex.lab = 1, cex.main = 1,
            lwd = 1, plot.seasons = FALSE)
#Goodness-of-fit for dynamic occupancy model
#Number of seasons:  5 
#Chi-square statistic:
#  Season 1 Season 2 Season 3 Season 4 Season 5 
#88.0585  91.0656  35.1793  33.1377  62.2055 
#Total chi-square = 309.6466 
#Number of bootstrap samples = 1000
#P-value = 0.009
#Quantiles of bootstrapped statistics:
#  0%  25%  50%  75% 100% 
#111  153  167  183  413 
#Estimate of c-hat = 1.8

