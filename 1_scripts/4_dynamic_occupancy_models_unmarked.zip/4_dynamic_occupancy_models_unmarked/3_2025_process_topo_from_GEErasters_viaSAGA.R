devtools::install_github("r-spatial/RSAGA", dependencies = TRUE)

library(tidyr)
library(dplyr)
library(sf)
library(terra)
library(raster)
library(RSAGA)

#get point counts
# yera<-read.csv("0_data/0_raw/point counts/YERA_2024_COLEXT_DATA_NAMECROSSWALK.csv", header=TRUE)
# str(yera)#247 rows
# nlevels(as.factor(yera$location))#247
# nlevels(as.factor(yera$locationC))#237
# 
# #Use the NOT rounded lat/ long when you can. Only when there is movement of the points slightly over time will the round be more appropriate
# yera2<-yera%>%
#   group_by(locationC)%>%
#   mutate(nSitesUsed=nlevels(as.factor(location)))%>%
#   group_by(locationC,nSitesUsed)%>%
#   summarise(lat=ifelse(nSitesUsed>1, R_latitude, latitude),
#             lon=ifelse(nSitesUsed>1, R_longitude, longitude))%>%
#   unique()#237 sites now
# 
# 
# plot(yera2$lon, yera2$lat) #no obvious points appear to be off.
# 
# #no missing coordinates
# E<-st_as_sf(yera2,
#             coords = c("lon", "lat"),
#             crs = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs +towgs84=0,0,0")

finalYERAsitesShapefile<-st_read("0_data/0_raw/point counts/allYERAsites_June2025.shp")

#load rasters from 2013 on Google Drive
raster_files <- list.files("G:/My Drive/Google Earth", pattern = "YERA_ALOS_DEM", full.names = TRUE)
rasters <- lapply(raster_files, terra::rast)#about 10 minutes
raster_sprc <- terra::sprc(rasters)#<1 minute to create spatraster collection
raster_mosaic<- terra::mosaic(raster_sprc, fun= "mean")#replace fun="mean"
writeRaster(raster_mosaic, "0_data/1_processed/2_topography/ALOS_dem_raster.tif", overwrite=TRUE)

#Following code for creating new topography variables via RSAGA
#did not work:
#convert to raster object
# to Raster* object
#dem_raster <- as(raster_mosaic, "Raster")

#Set up connection to RSAGA
#https://cran.r-project.org/web/packages/RSAGA/vignettes/RSAGA.html
#env <- rsaga.env()

#my_env <- rsaga.env(workspace=substr(path_saga, 1, nchar(path_saga)-1),
#                    path=sagapath, modules=sagamods)

#install.packages("remotes")
#remotes::install_github("joaofgoncalves/SegOptim")
#remotes::install_github("bcgov/wetlandmapR")
# library(wetlandmapR)
# create_dem_products(
#   "E:/OSM Good Cumulative Effects/OSM 2024 Yellow Rail/OSM 2025 Yellow Rail Occupancy/0_data/1_processed/0_spatial data extracted/topography/ALOS_dem_raster.tif",
#   stream_vec = NULL,
#   burn_val = NULL,
#   "E:/OSM Good Cumulative Effects/OSM 2024 Yellow Rail/OSM 2025 Yellow Rail Occupancy/0_data/1_processed/0_spatial data extracted/topography",
#   products = c("MRVBF", "TPI", "TOPOWET")
# )

#Created new topography rasters directly in SAGA, saved as both
#SAGA rasters and .tif files outside of SAGA

#load elevation raster
elevation<-rast("0_data/1_processed/2_topography/ALOS_dem_raster.tif")

#make 150-m buffer for data extraction
E150<-finalYERAsitesShapefile%>%
  st_transform(crs=crs(elevation))%>%
  st_buffer(150)
#summarize metrics for elevation within 150 m
elv <- terra::extract(elevation, vect(E150), function(x) mean(x, na.rm = T))#instead of fun="mean"
finalYERAsitesShapefile$elevation<-elv$DSM

#load SWI raster
SWI<-rast("0_data/1_processed/2_topography/SWI.tif")

#summarize metrics for SWI within 150 m
swi <- terra::extract(SWI, vect(E150), function(x) mean(x, na.rm = T))#instead of fun="mean"
finalYERAsitesShapefile$swi<-swi$

#load TWI raster
TPI500<-rast("0_data/1_processed/2_topography/TPI500m.tif")

#summarize metrics for TWI within 150 m
tpi500 <- terra::extract(TPI500, vect(E150), function(x) mean(x, na.rm = T))#instead of fun="mean"
finalYERAsitesShapefile$mrvbf<-tpi500$

#load MRVBF raster
mrvbf<-rast("0_data/1_processed/2_topography/MRVBF.tif")

#summarize metrics for MRVBF within 150 m
vbf <- terra::extract(mrvbf, vect(E150), function(x) mean(x, na.rm = T))#instead of fun="mean"
finalYERAsitesShapefile$mrvbf<-vbf$DSM

#I have no idea how to interpret these tif file outputs from SAGA-GIS
#so I did the data extractions inside SAGA-GIS. Yellow Rail sites should
#be (and were) associated with higher MRVBF values and lower MRRTF values,
#higher values for SWI, and lower, often negative values for TPI.
#By that, I mean mean values for these variables within 150 m.